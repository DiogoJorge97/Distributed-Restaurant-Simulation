/**
 * Package containing classes used by the bar - Server side of the problem
 */
package bar;

