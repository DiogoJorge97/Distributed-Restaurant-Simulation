/**
 * Package containing server stubs
 */

package stubs;

