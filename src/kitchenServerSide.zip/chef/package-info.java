/**
 * Package containing classes used by the chef - Client side of the problem
 */

package chef;

