/**
 * Package containing the interacting entities states
 */
package entities_states;
