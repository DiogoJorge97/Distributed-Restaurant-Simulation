package entities_states;

/**
 * @author Diogo Jorge
 */
public enum Chef_State {
    /*WAITING_FOR_ORDER, PREPARING_THE_COURSE, DISHING_THE_PORTIONS,
    DELIVERING_THE_PORTIONS, CLOSING_SERVICE;
    */
    WFO, PTC, DIP, DLP, CTS;
}
