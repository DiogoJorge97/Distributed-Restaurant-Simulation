package entities_states;

/**
 * @author Diogo Jorge
 */
public enum Waiter_State {
    /*
        APPRAISING_THE_SITUATION, PRESENTING_THE_MENU, TAKING_THE_ORDER, PLACING_THE_ORDER,
        WAITING_FOR_PORTION, PROCESSING_THE_BILL, RECEIVING_PAYMENT;
     */
    ATS, PTM, TTO, PTO, WFP, PTB, RTP;
}
