package entities_states;

/**
 * @author Diogo Jorge
 */
public enum Student_State {
    /*GOING_TO_THE_RESTAURANT, TAKING_A_SEAT_THE_TABLE, SELECTING_THE_COURSES,
    ORGANIZING_THE_ORDER, CHATTING_WITH_COMPANIONS, ENJOYING_THE_MEAL,PAYING_THE_BILL, GOING_HOME ;
     */
    GTR, TST, STC, OTO, CWC, ETM, PTB, SGH;
}
