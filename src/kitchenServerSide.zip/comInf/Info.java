/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package comInf;

/**
 * Problem's general information
 * @author Diogo Jorge
 */
public class Info {

    public static int coursesNumber = 3;
    public static int studentNumber = 7;
    public static String filename = "/home/cd0208/CDSockets/RestauranteSocket/generalRepository/logger.txt";
    public static String tableHostName = "l040101-ws04.ua.pt";
    public static int tablePortNumber = 22674;
    public static String barHostName = "l040101-ws03.ua.pt";
    public static int barPortNumber = 22673;
    public static String kitchenHostName = "l040101-ws02.ua.pt";
    public static int kitchenPortNumber = 22672;
    public static String generalRepoHostName = "l040101-ws01.ua.pt";
    public static int generalRepoPortNumber = 22671;

//    public static String filename = "src/logger.txt";
//    public static String tableHostName = "localhost";
//    public static String barHostName = "localhost";
//    public static String kitchenHostName = "localhost";
//    public static String generalRepoHostName = "localhost";

}
