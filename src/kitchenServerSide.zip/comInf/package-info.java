/**
 * Package containing classes with general information, messages and message exceptions
 */
package comInf;

